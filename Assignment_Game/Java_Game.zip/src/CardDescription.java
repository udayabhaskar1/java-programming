/*
This class gives a description of the card that is currently being played.
 */
import javax.swing.*;
import java.awt.*;

public abstract class CardDescription {

    public abstract String getName();

    public abstract String getNewCurrentCategory(String current_category);

    public abstract double getNewCurrentValue(String current_category);

    public abstract boolean checkIfPlayable(String current_category, double current_value);
}
