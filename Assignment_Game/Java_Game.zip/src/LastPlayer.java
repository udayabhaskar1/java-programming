import java.util.ArrayList;             //implementing a list

public class LastPlayer {
    int number;
    String name;
    ArrayList<CardDescription> hand;
    Boolean can_play,winner;

    public LastPlayer()
    {
        number = 1;
        name = "Player 1";
        hand = new ArrayList<CardDescription>();
        can_play = true;
        winner = false;
    }

    public LastPlayer(int num, String n)
    {
        number = num;
        name = n;
        hand = new ArrayList<CardDescription>();
        can_play = true;
        winner = false;
    }

    public boolean canTheyPlay()
    {
        return can_play;
    }

    public int getPlayerNumber()
    {
        return number;
    }

    public boolean getWinStatus()
    {
        return winner;
    }

    public ArrayList<CardDescription> getHand()
    {
        return hand;
    }

    public ArrayList<String> getCardsInHand()
    {
        ArrayList<String> cardnames = new ArrayList<>();
        for (int i=0; i < hand.size(); ++i)
        {
            cardnames.add(hand.get(i).getName());
        }
        return cardnames;
    }

    public String getName()
    {
        return name;
    }

    public void changeHand(ArrayList<CardDescription> h)
    {
        hand = h;
    }

    public void changePlayStatus(boolean newstatus)
    {
        can_play = newstatus;
    }

    public void changeWinStatus(boolean newstatus)
    {
        winner = newstatus;
    }
}
