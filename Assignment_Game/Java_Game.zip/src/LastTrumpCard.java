import java.util.Scanner;

public class LastTrumpCard extends CardDescription
{
    String name, category;

    public LastTrumpCard()
    {
        name = "Unnamed_Trump";
        category = "your choice";
    }

    public LastTrumpCard(String cardName, String cardCategory)
    {
        name = cardName;
        if (cardCategory.equals("hardness") || cardCategory.equals("specific gravity") || cardCategory.equals("crystal abundance") || cardCategory.equals("economic value") || cardCategory.equals("cleavage") || cardCategory.equals("your choice"))
        {
            category = cardCategory;
        }
        else
        {
            System.out.println("The category entered is not valid, please enter a valid trump category:");
            Scanner scanner = new Scanner(System.in);
            String validcategory = scanner.nextLine();
            this.changeCategory(validcategory);
        }
    }

    public void showStats()
    {
        System.out.printf("%20s", name + ":");
        System.out.println(" allows a player to change the playable trump to "+ category + ".");
    }

    public void changeName(String newname)
    {
        name = newname;
    }

    public void changeCategory(String newcategory)
    {
        switch(newcategory)
        {
            case "hardness":
                category = newcategory;
                break;
            case "specific gravity":
                category = newcategory;
                break;
            case "economic value":
                category = newcategory;
                break;
            case "crystal abundance":
                category = newcategory;
                break;
            case "cleavage":
                category = newcategory;
                break;
            default:
                System.out.println("The trump you entered was invalid, please enter a valid trump category:");
                Scanner newscanner = new Scanner(System.in);
                this.changeCategory(newscanner.nextLine());
        }
    }

    public String getName()
    {
        return name;
    }

    public String getCategory()
    {
        return category;
    }

    public String getNewCurrentCategory(String current_category)
    {
        if (category.equals("your choice"))
        {
            System.out.println("Which category do you want the new playable trump to be?");
            Scanner scanner = new Scanner(System.in);
            String newcategory = scanner.nextLine();
            switch(newcategory.toLowerCase())
            {
                case "hardness":
                    current_category = "hardness";
                    break;
                case "economic value":
                    current_category = "economic value";
                    break;
                case "cleavage":
                    current_category = "cleavage";
                    break;
                case "specific gravity":
                    current_category = "specific gravity";
                    break;
                case "crystal abundance":
                    current_category = "crystal abundance";
                    break;
                default:
                    System.out.println("Your answer was unclear, pick one of the five categories:");
                    System.out.println(" hardness, specific gravity, economic value, crystal abundance, or cleavage");
                    getNewCurrentCategory(current_category);
            }
        }
        else
        {
            current_category = category;
        }
        return current_category;
    }

    public double getNewCurrentValue(String current_category)
    {
        return -1;
    }

    public boolean checkIfPlayable(String current_category, double current_value)
    {return true;}

}
