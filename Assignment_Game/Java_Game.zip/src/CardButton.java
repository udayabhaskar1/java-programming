/**
 * Created by Udaya Bhaskar Reddy on 30/9/2017.
 */
import javax.swing.*;               // importing the set of components to create the GUI
import java.awt.*;

public class CardButton extends JButton
{
    String string;
    ImageIcon image = new ImageIcon("C:\\Users\\udayb\\Desktop\\CP2406_Uday_A2-master\\images\\"+string+".jpg");
    JPanel panel = new JPanel();
    JLabel label = new JLabel();
    Dimension size = new Dimension(130,190);

    public CardButton()
    {
        panel.setSize(size);
        add(panel);
        panel.add(label);
        string = "unassigned";
        validate();
        repaint();
    }

    public CardButton(String new_string)
    {
        panel.setSize(size);
        add(panel);
        panel.add(label);
        string = new_string;
        validate();
        repaint();
    }

    public String getName()
    {
        return string;
    }

    public void renameButton(String new_string)
    {
        panel.setPreferredSize(size);
        string = new_string;
        image =  new ImageIcon("C:\\Users\\udayb\\Desktop\\CP2406_Uday_A2-master\\images\\"+string+".jpg");
        label.setIcon(imageTransform1(image));
        validate();
        repaint();
    }

    public ImageIcon imageTransform1(ImageIcon i)
    {
        Image image = i.getImage();
        Image new_image = image.getScaledInstance(130,200, Image.SCALE_SMOOTH);
        return (new ImageIcon(new_image));
    }
}
