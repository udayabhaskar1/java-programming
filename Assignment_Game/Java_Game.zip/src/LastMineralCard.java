import static java.lang.Math.round;

public class LastMineralCard extends CardDescription
{
    String name;
    double hardness, specificGravity;
    double crystalAbundance, economicValue, cleavage;

    public LastMineralCard()
    {
        name = "Unnamed_Mineral";               // setting the values to zero
        hardness = 0;
        specificGravity = 0;
        cleavage = 0;
        crystalAbundance = 0;
        economicValue = 0;
    }

    public LastMineralCard(String n, double h, double sg, String cl, String ca, String ev)
    {
        name = n;
        hardness = h;
        if (h < 1 || h > 10)
        {
            System.out.println("Hardness must be between 1 and 10 based on Moh's hardness scale.");
            System.out.println("Hardness set to 1 by default.");
            hardness = 1;
        }
        specificGravity = sg;
        cleavage = categoryToCleavage(cl);
        crystalAbundance = categoryToAbundance(ca);
        economicValue = categoryToEconomicValue(ev);
    }

    public void showStats()
    {
        String cv,ca,ev;
        cv = cleavageToCategory(cleavage);
        ca = abundanceToCategory(crystalAbundance);
        ev = economicvalueToCategory(economicValue);
        System.out.printf("%20s", name + ":");
        System.out.printf("%11s", "hardness:");
        System.out.printf("%4s", hardness);
        System.out.printf("%18s", "specific gravity:");
        System.out.printf("%4s", specificGravity);
        System.out.printf("%11s", "cleavage:");
        System.out.printf("%20s", cv);
        System.out.printf("%20s", "crystal abundance:");
        System.out.printf("%10s", ca);
        System.out.printf("%18s", "economic value:");
        System.out.printf("%10s", ev);
        System.out.println("");
    }

    public double categoryToCleavage(String cleave)
    {
        switch(cleave)
        {
            case "none":
                cleavage = 0;
                break;
            case "poor/none":
                cleavage = 1;
                break;
            case "1 poor":
                cleavage = 2;
                break;
            case "2 poor":
                cleavage = 3;
                break;
            case "1 good":
                cleavage = 4;
                break;
            case "1 good, 1 poor":
                cleavage = 5;
                break;
            case "2 good":
                cleavage = 6;
                break;
            case "3 good":
                cleavage = 7;
                break;
            case "1 perfect":
                cleavage = 8;
                break;
            case "1 perfect, 1 good":
                cleavage = 9;
                break;
            case "1 perfect, 2 good":
                cleavage = 10;
                break;
            case "2 perfect, 1 good":
                cleavage = 11;
                break;
            case "3 perfect":
                cleavage = 12;
                break;
            case "4 perfect":
                cleavage = 13;
                break;
            case "6 perfect":
                cleavage = 14;
                break;
            default:
                System.out.println("Cleavage unclear.");
                System.out.println("Cleavage set to none by default.");
                cleavage = 0;
                break;
        }
        return cleavage;
    }

    public String cleavageToCategory(double cleavage)
    {
        int rounded = (int) round(cleavage);
        String cleave="";
        switch(rounded)
        {
            case 0:
                cleave = "none";
                break;
            case 1:
                cleave = "poor/none";
                break;
            case 2:
                cleave = "1 poor";
                break;
            case 3:
                cleave = "2 poor";
                break;
            case 4:
                cleave = "1 good";
                break;
            case 5:
                cleave = "1 good, 1 poor";
                break;
            case 6:
                cleave = "2 good";
                break;
            case 7:
                cleave = "3 good";
                break;
            case 8:
                cleave = "1 perfect";
                break;
            case 9:
                cleave = "1 perfect, 1 good";
                break;
            case 10:
                cleave = "1 perfect, 2 good";
                break;
            case 11:
                cleave = "2 perfect, 1 good";
                break;
            case 12:
                cleave = "3 perfect";
                break;
            case 13:
                cleave = "4 perfect";
                break;
            case 14:
                cleave = "6 perfect";
                break;
            default:
                System.out.println("Error in cleavage value.");
                System.out.println("Cleave set to 'none' by default.");
                break;
        }
        return cleave;
    }

    public double categoryToAbundance(String rarity)
    {
        double ca=7;
        switch(rarity)
        {
            case "ultratrace":
                ca = 0;
                break;
            case "trace":
                ca = 1;
                break;
            case "low":
                ca = 2;
                break;
            case "moderate":
                ca = 3;
                break;
            case "high":
                ca = 4;
                break;
            case "very high":
                ca = 5;
                break;
            default:
                System.out.println("Crystal abundance unclear.");
                System.out.println("Crystal abundance set to ultratrace by default.");
                ca = 0;
                break;
        }
        return ca;
    }

    public String abundanceToCategory(double crystal_abundance)
    {
        int rounded = (int) round(crystal_abundance);
        String rarity = "";
        switch(rounded)
        {
            case 0:
                rarity = "ultratrace";
                break;
            case 1:
                rarity = "trace";
                break;
            case 2:
                rarity = "low";
                break;
            case 3:
                rarity = "moderate";
                break;
            case 4:
                rarity = "high";
                break;
            case 5:
                rarity = "very high";
                break;
            default:
                System.out.println("Crystal Abundance unclear.");
                System.out.println("Crystal Abundance set to ultratrace by default.");
                rarity = "ultratrace";
                break;
        }
        return rarity;
    }

    public double categoryToEconomicValue(String price)
    {
        byte ev;
        switch(price)
        {
            case "trivial":
                ev = 0;
                break;
            case "low":
                ev = 1;
                break;
            case "moderate":
                ev = 2;
                break;
            case "high":
                ev = 3;
                break;
            case "very high":
                ev = 4;
                break;
            case "I'm rich!":
                ev = 5;
                break;
            default:
                System.out.println("Economic value unclear.");
                System.out.println("Economic value set to trivial by default.");
                ev = 0;
                break;
        }
        return ev;
    }

    public String economicvalueToCategory(double economic_value)
    {
        int rounded = (int) round(economic_value);
        String price = "";
        switch(rounded)
        {
            case 0:
                price = "trivial";
                break;
            case 1:
                price = "low";
                break;
            case 2:
                price = "moderate";
                break;
            case 3:
                price = "high";
                break;
            case 4:
                price = "very high";
                break;
            case 5:
                price = "I'm rich!";
                break;
            default:
                System.out.println("Economic value is unclear.");
                System.out.println("Economic value set to trivial by default.");
                price = "trivial";
        }
        return price;
    }

    public String getName()
    {
        return name;
    }

    public double getHardness()
    {
        return hardness;
    }

    public double getGravity()
    {
        return specificGravity;
    }

    public double getAbundance()
    {
        return crystalAbundance;
    }

    public double getValue()
    {
        return economicValue;
    }

    public double getCleavage()
    {
        return cleavage;
    }

    public String getNewCurrentCategory(String current_category)
    {
        return current_category;
    }

    public double getNewCurrentValue(String current_category)
    {
        double newvalue = -1;
        switch(current_category)
        {
            case "hardness":
                newvalue = hardness;
                break;
            case "economic value":
                newvalue = economicValue;
                break;
            case "specific gravity":
                newvalue = specificGravity;
                break;
            case "crystal abundance":
                newvalue = crystalAbundance;
                break;
            case "cleavage":
                newvalue = cleavage;
                break;
            default:
                System.out.println("");
                break;

        }
        if (newvalue==-1)
        {
            System.out.println("");
        }
        return newvalue;
    }

    public boolean checkIfPlayable(String current_category, double current_value)
    { boolean returns = true;
        if(current_category.equals("hardness"))
        {
            if(getHardness() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        if(current_category.equals("specific gravity"))
        {
            if(getGravity() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        if(current_category.equals("economic value"))
        {
            if(getValue() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        if(current_category.equals("crystal abundance"))
        {
            if(getAbundance() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        if(current_category.equals("cleavage"))
        {
            if(getCleavage() > current_value)
            {
                returns = true;
            }
            else
            {
                returns = false;
            }
        }
        return returns;
    }

}